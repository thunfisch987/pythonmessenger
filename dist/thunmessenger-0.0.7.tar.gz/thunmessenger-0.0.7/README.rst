# pythonmessenger

A local-network Messenger written in Python

Dependencies:
    - dataclasses
    - IPy
    - playsound
